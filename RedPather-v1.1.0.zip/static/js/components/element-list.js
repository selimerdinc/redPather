/**
 * Element List Manager
 * Handles the left sidebar list items, editing, and actions.
 */
class ElementListManager {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        if (window.appState) {
            window.appState.subscribe('ui.currentHoverIndex', (idx) => this.handleHighlight(idx));
        }
    }

    render(elements) {
        if (!this.container) return;
        this.container.innerHTML = '';
        elements.forEach((el) => {
            if (!el.isDeleted) {
                const item = this.createListItem(el);
                this.container.appendChild(item);
            }
        });
    }

    createListItem(el) {
        const index = el.index;
        const item = document.createElement('div');
        item.id = `list-item-${index}`;
        item.className = 'list-item p-4 rounded-lg mb-2 cursor-pointer group relative flex flex-col gap-2 border border-[#27272a]';

        let badgeClass = "bg-gray-800 text-gray-400 border border-gray-700";
        if (el.strategy.includes('ID')) badgeClass = "bg-blue-900/30 text-blue-400 border border-blue-800";
        else if (el.strategy.includes('ACC_ID')) badgeClass = "bg-emerald-900/30 text-emerald-400 border border-emerald-800";
        else if (el.strategy.includes('ANCHOR')) badgeClass = "bg-pink-900/30 text-pink-400 border border-pink-800";
        else if (el.strategy.includes('TEXT')) badgeClass = "bg-purple-900/30 text-purple-400 border border-purple-800";

        const header = document.createElement('div');
        header.className = "flex items-center justify-between w-full";
        header.innerHTML = `
            <div class="flex items-center gap-2">
                <span class="text-[10px] font-mono font-bold text-gray-500">#${String(index + 1).padStart(2, '0')}</span>
                <span class="text-[9px] font-bold px-1.5 py-0.5 rounded border ${badgeClass}">${el.strategy}</span>
            </div>
        `;
        if (el.text) {
            const textSpan = document.createElement('span');
            textSpan.className = "text-[10px] text-gray-500 truncate max-w-[120px]";
            textSpan.title = el.text;
            textSpan.textContent = el.text;
            header.appendChild(textSpan);
        }
        item.appendChild(header);

        const varContainer = document.createElement('div');
        varContainer.className = "w-full";
        const varCode = document.createElement('code');
        varCode.className = "block text-[13px] text-red-400 font-bold break-all hover:text-red-300 transition-colors cursor-text mb-1 border border-transparent hover:border-red-900/30 rounded px-1 -mx-1";
        varCode.title = "Çift tıkla düzenle";
        varCode.textContent = el.variable;
        varCode.ondblclick = (e) => {
            e.stopPropagation();
            if (window.startEdit) window.startEdit(varCode, index, 'variable');
        };
        varContainer.appendChild(varCode);

        const locCode = document.createElement('code');
        locCode.className = "block text-[10px] text-gray-600 bg-[#09090b] px-2 py-1.5 rounded border border-[#27272a] break-all font-mono hover:text-gray-400 hover:border-gray-500 transition-colors cursor-text";
        locCode.title = "Çift tıkla düzenle";
        locCode.textContent = el.locator;
        locCode.ondblclick = (e) => {
            e.stopPropagation();
            if (window.startEdit) window.startEdit(locCode, index, 'locator');
        };
        varContainer.appendChild(locCode);
        item.appendChild(varContainer);

        const actions = document.createElement('div');
        actions.className = "flex items-center gap-2 w-full mt-1";
        const verifyBtn = this.createActionButton(
            `<svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7"></path></svg>`,
            "Doğrula"
        );
        verifyBtn.onclick = (e) => this.handleVerify(e, index, verifyBtn, el.locator);
        actions.appendChild(verifyBtn);

        const copyBtn = this.createActionButton(
            `<svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>`,
            "Kopyala"
        );
        copyBtn.onclick = (e) => this.handleCopy(e, el);
        actions.appendChild(copyBtn);

        if (window.app && window.app.isAiEnabled) {
            const aiBtn = this.createActionButton(
                `<svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>`,
                "AI XPath Önerisi"
            );
            aiBtn.onclick = (e) => {
                e.stopPropagation();
                if (window.app && window.app.startAiXpathSuggest) window.app.startAiXpathSuggest(el, el.index);
            };
            actions.appendChild(aiBtn);
        }

        // Input alanları için metin gönderme butonu
        const isInput = el.variable && (el.variable.includes('input') || el.variable.includes('field') || el.variable.includes('text'));
        if (isInput) {
            const sendTextBtn = this.createActionButton(
                `<svg class="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>`,
                "Metin Gönder"
            );
            sendTextBtn.onclick = (e) => {
                e.stopPropagation();
                if (window.showInputModal) window.showInputModal(el.locator, el.text || el.variable);
            };
            actions.appendChild(sendTextBtn);
        }

        const deleteBtn = this.createActionButton(
            `<svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>`,
            "Sil",
            true
        );
        deleteBtn.onclick = (e) => {
            e.stopPropagation();
            // Global removeElement fonksiyonu çağrılıyor mu?
            if (window.removeElement) window.removeElement(e, index);
        };
        actions.appendChild(deleteBtn);
        item.appendChild(actions);

        // --- Context Menu (Right Click) ✅ EKLENDİ ---
        item.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            if (window.app && window.app.contextMenu) {
                window.app.contextMenu.show(e.clientX, e.clientY, el);
            }
        });

        item.addEventListener('mouseenter', () => { if (window.highlightElement) window.highlightElement(index, false); });
        item.addEventListener('mouseleave', () => { if (window.clearSelection) window.clearSelection(); });

        return item;
    }

    createActionButton(iconHtml, title, isDelete = false) {
        const btn = document.createElement('button');
        btn.className = `action-btn ${isDelete ? 'delete ml-auto' : ''}`;
        btn.title = title;
        btn.innerHTML = iconHtml;
        return btn;
    }

    async handleVerify(e, index, btn, locator) {
        e.stopPropagation();
        const originalHtml = btn.innerHTML;
        btn.innerHTML = `<div class="loader"></div>`;
        try {
            const result = window.api ? await window.api.verifyLocator(locator) : await window.apiCall('/api/verify', { method: 'POST', body: JSON.stringify({ locator }) });
            const data = result.data || result;
            if (data.valid) {
                btn.innerHTML = `<span class="text-emerald-500 font-bold text-sm">✓</span>`;
                window.app.ui.showToast("Doğrulandı", `Eşleşme: ${data.count}`, 'success');
            } else {
                btn.innerHTML = `<span class="text-red-500 font-bold text-sm">✕</span>`;
                window.app.ui.showToast("Başarısız", `Bulunan: ${data.count}`, 'error');
            }
        } catch (err) {
            btn.innerHTML = `<span class="text-yellow-500 font-bold text-sm">!</span>`;
            console.error(err);
            window.app.ui.showToast("Hata", "Doğrulama başarısız", 'error');
        }
        setTimeout(() => btn.innerHTML = originalHtml, 2000);
    }

    handleCopy(e, el) {
        e.stopPropagation();
        const txt = `\${${el.variable.replace(/[${}]/g, '')}}\t${el.locator}`;
        navigator.clipboard.writeText(txt).then(() => window.app.ui.showToast("Kopyalandı", "Satır kopyalandı", 'success'));
    }

    handleHighlight(index) {
        const oldActive = this.container.querySelector('.list-item.active');
        if (oldActive) oldActive.classList.remove('active', 'flash');
        if (index === -1) return;
        const newActive = document.getElementById(`list-item-${index}`);
        if (newActive) {
            newActive.classList.add('active');
        }
    }

    scrollToIndex(index) {
        window.debug?.log("Attempting to scroll to index:", index);
        const item = document.getElementById(`list-item-${index}`);
        if (item) {
            window.debug?.log("Element found, scrolling...", item);
            item.scrollIntoView({ behavior: 'auto', block: 'center' });
            item.classList.remove('flash');
            void item.offsetWidth;
            item.classList.add('flash');
        } else {
            console.warn("Element NOT found for scrolling:", `list-item-${index}`);
        }
    }
}

window.ElementListManager = ElementListManager;